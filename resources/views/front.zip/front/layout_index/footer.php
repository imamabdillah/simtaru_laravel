

    <!-- jQuery -->
    <script src="<?= base_url('assets/front_20232/') ?>js/jquery-3.6.0.min.js"></script>
    <script src="<?= base_url('assets/front_20232/') ?>js/jquery-migrate-3.4.0.min.js"></script>

    <!-- plugins -->
    <script src="<?= base_url('assets/front_20232/') ?>js/plugins.js"></script>
    <script src="<?= base_url('assets/front_20232/') ?>js/ScrollTrigger.min.js"></script>
    <script src="<?= base_url('assets/front_20232/') ?>js/animsition.min.js"></script>

    <!-- custom scripts -->
    <script src="<?= base_url('assets/front_20232/') ?>js/scripts.js"></script>

    <!-- data tabel -->
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap4.min.js"></script>

</body>

</html>