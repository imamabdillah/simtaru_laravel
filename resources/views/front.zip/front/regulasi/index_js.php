<script>
$(document).ready(function(){
    $('#table_regulasi').dataTable();
})
</script>