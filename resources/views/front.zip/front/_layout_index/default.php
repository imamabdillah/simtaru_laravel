<!-- Main Container -->
<main id="main-container">
    <!-- Hero -->
    <div class="bg-primary">
        <div class="bg-pattern bg-black-op-25" style="background-image: url('<?= base_url();?>assets/img/various/bg-pattern.png');">
            <div class="content content-top text-center">
                <div class="py-50">
                    <h1 class="font-w700 text-white mb-10">Mohon Maaf</h1>
                    <h2 class="h4 font-w400 text-white-op">Halaman ini sedang dalam proses perbaikan.</h2>
                </div>
            </div>
        </div>
    </div>
    <!-- END Hero -->

</main>
<!-- END Main Container -->