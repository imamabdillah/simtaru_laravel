<div>
    <?php //var_dump($publikasi) 
    ?>
</div>

<div style="padding: 40px;">
    <div>
        <span><i class="fa fa-calendar"></i> <?= $publikasi['added'] ?></span> |
        <span><i class="fa fa-pencil"></i> <?= $publikasi['nama'] ?></span>
    </div>
    <div style="margin-top: 40px;"><?= $publikasi['isi'] ?></div>

</div>