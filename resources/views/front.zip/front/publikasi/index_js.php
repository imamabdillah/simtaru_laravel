<script>
$(document).ready(function(){
    $('#table_publikasi').dataTable();
})
</script>