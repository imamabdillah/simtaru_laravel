<script>
$(document).ready(function(){
    $('#table_informasi_dasar, #table_rencana_tata_ruang, #table_informasi_tata_ruang').dataTable();
})
</script>